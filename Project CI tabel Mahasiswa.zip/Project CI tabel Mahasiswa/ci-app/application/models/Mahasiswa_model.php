<?php

class Mahasiswa_model extends CI_model {
    public function getAllMahasiswa()
    {
        return $this->db->get('mahasiswa')->result_array();
        
    }
    public function tambahDataMahasiswa()
    {
        $data = [
            "nama" => $this->input->post('nama',true),
            "nrp" => $this->input->post('nrp',true),
            "email" => $this->input->post('email',true),
            "jurusan" => $this->input->post('jurusan',true)
        ]; //datanya berbentuk array untuk nambahin inputan data pada kolom tambah data mahasiswa
        // ada tambahan 'true' semacam mekanisme security dari Code igniter
        $this->db->insert('mahasiswa',$data); //menambahkan data yang telah diinput kedalam kontroller mahasiswa
    }
    public function hapusDataMahasiswa($id)
    {
        $this->db->where('id',$id);
        $this->db->delete('mahasiswa'); //jika mengubah table data menggunakan kondisi
        //seharusnya kondisi dari pengubahan tsb diletakkan sebelum fungsi pengubahan tersebut
    }
}