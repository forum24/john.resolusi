
    <h1>Hello, <?php echo $nama; ?></h1>

 